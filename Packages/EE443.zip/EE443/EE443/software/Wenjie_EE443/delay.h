/*
 * delay.h
 *
 *  Created on: Jan 23, 2014
 *      Author: zhwj814
 */

#ifndef DELAY_H_
#define DELAY_H_




#endif /* DELAY_H_ */

void delay(int delay_time);
