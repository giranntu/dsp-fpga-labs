/*
 * uart.h
 *
 *  Created on: Jan 27, 2014
 *      Author: zhwj814
 */

#ifndef UART_H_
#define UART_H_




#endif /* UART_H_ */

void uart_sendByte(char data);
void uart_sendInt(int data);
void uart_sendFloat(float data);
char uart_byteRecv();
//char* uart_charArrayRecv(int length);
