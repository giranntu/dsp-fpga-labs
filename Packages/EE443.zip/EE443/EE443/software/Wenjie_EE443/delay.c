/*
 * delay.c
 *
 *  Created on: Jan 23, 2014
 *      Author: zhwj814
 */


void delay(int delay_time){
	int i = 0;
	int j = 0;
	for(i = 0; i < delay_time; i++){
		j++;
	}
}

